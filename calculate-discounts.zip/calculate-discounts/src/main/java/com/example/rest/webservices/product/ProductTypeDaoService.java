package com.example.rest.webservices.product;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class ProductTypeDaoService {

	///////////////////////////////////////////////////
	// Demo List of Users
	///////////////////////////////////////////////////	
	private static List<Product> products = new ArrayList<Product>();

	
	static {
		products.add(new Product(1,"Product One","grocery"));
		products.add(new Product(2,"Product Two","retail"));
		products.add(new Product(3,"Product Three","pharmacy"));
		
	}
	
	
	///////////////////////////////////////////////////
	// Find a product
	///////////////////////////////////////////////////	
	
	public Product findProduct(int id) {
		for(Product product:products) {
			if(product.getId()==id) {
				return product;
			}
		}
		return null;
	}
	
	///////////////////////////////////////////////////
	// Find all products
	///////////////////////////////////////////////////	
	public List<Product> findAllProducts() {
			return products;
	}
}
