package com.example.rest.webservices.bill;

import java.util.Date;


public class Bill {
	
	private Integer id;
	private String customerName;
	//@Size(min=4)
	//@NotBlank(message = "Id is mandatory")
	private String customerid;
	//@NotBlank(message = "Porduct Id is mandatory")
	private Integer productId;
	private Double amount;
	private Date dateOfPurchase;
	
	protected Bill() { }
	
	public Bill(Integer id, String customerName, String customerid, Integer productId, 
			Double amount, Date dateOfPurchase) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.customerid = customerid;
		this.productId = productId;
		this.amount = amount;
		this.dateOfPurchase = dateOfPurchase;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProduct(Integer productId) {
		this.productId = productId;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Date getDateOfPurchase() {
		return dateOfPurchase;
	}
	public void setDateOfPurchase(Date dateOfPurchase) {
		this.dateOfPurchase = dateOfPurchase;
	}

	@Override
	public String toString() {
		return "Bill [id=" + id + ", customerName=" + customerName + ", customerid=" + customerid + ", productId="
				+ productId + ", amount=" + amount + ", dateOfPurchase=" + dateOfPurchase + "]";
	}
	
	
}
