package com.example.rest.webservices.discounts;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.rest.webservices.bill.Bill;
import com.example.rest.webservices.bill.BillGet;
import com.example.rest.webservices.product.Product;
import com.example.rest.webservices.product.ProductTypeDaoService;
import com.example.rest.webservices.user.User;
import com.example.rest.webservices.user.UserDaoService;
import com.example.rest.webservices.user.UserNotFoundException;
import com.example.rest.webservices.utils.Constants;
import com.example.rest.webservices.utils.Utils;


@Service
public class CalclulateDiscountService {
	
	
	//////////////////////////////////////////////
	// Calculate Discounts
	//////////////////////////////////////////////
	@Autowired
	private UserDaoService userService;
	
	@Autowired
	private ProductTypeDaoService productService;
	
	
	public Discount getDiscount(Bill bill) {
		return calculateDiscount(bill);
	}
	
	public Discount getDiscount(BillGet bill) {
		return calculateDiscount(bill);
	}
	
	public String getHello(Bill bill) {
		return "hello";
	}
	
	private Discount calculateDiscount(BillGet bill) {
	
		try {
			Boolean isDoscountApplied = false;
			Double discountAmount = 0.0;
			int discountPercentage = 0;
			
			User user = userService.findUser(bill.getCustomerid());
			if(null==user)
				throw new UserNotFoundException("user id -" + bill.getCustomerid());
			
			Product product = productService.findProduct(Integer.parseInt(bill.getProductId()));
			
			
			// Rule 0 - The percentage based discounts do not apply on groceries.
			if(! product.getCategory().toUpperCase().contains(Constants.DISCOUNT_PRODUCT_CATEGORY))
			{
				// Rule 1 - If the user is an employee of the store, he gets a 30% discount
				if(user.getId().toUpperCase().contains(Constants.USER_EMPLOYEE)) {
					discountPercentage = Constants.EMPLOYEE_DISCOUNT;
					isDoscountApplied = true;
					
				}
				
				// Rule 2 - If the user is an affiliate of the store, he gets a 10% discount
				else if(user.getId().toUpperCase().contains(Constants.USER_AFFLIATE)) {
					discountPercentage = Constants.AFFLIATE_DISCOUNT;
					isDoscountApplied = true;
					
				}
					
				// Rule 3 - If the user has been a customer for over 2 years, he gets a 5% discount.
				else if(user.getId().toUpperCase().contains(Constants.USER_GENERAL) 
						&& Utils.numberOfYears(user.getJoiningDate(), 
								new Utils().convertToDate(bill.getDateOfPurchase())) > 2) {
					discountPercentage = Constants.EMPLOYEE_DISCOUNT;
					isDoscountApplied = true;
				}
			 }
			  
			// Rule 4 - For every $100 on the bill, there would be a $ 5 discount 
			// (e.g. for $ 990, you get $ 45 as a discount).
			if (isDoscountApplied)
				discountAmount =  Double.parseDouble(bill.getAmount()) * discountPercentage / 100.00 ;			
			else {	
					double multiply = (double)Double.parseDouble(bill.getAmount())/100 ;
					discountAmount = 5 * multiply;
				}	
			// Rule 6 - A user can get only one of the percentage based discounts on a bill.
			
			return new Discount(bill.getCustomerid(), bill.getCustomerName(), 
								Integer.parseInt(bill.getId()), product.getName(), product.getCategory(),
								discountAmount, discountPercentage, new Date());
		
		} catch(Exception ex) {
			throw ex;
		}
	}
	private Discount calculateDiscount(Bill bill) {
		
		Boolean isDoscountApplied = false;
		Double discountAmount = 0.0;
		int discountPercentage = 0;
		
		User user = userService.findUser(bill.getCustomerid());
		if(null==user)
			throw new UserNotFoundException("user id -" + bill.getCustomerid());
		
		Product product = productService.findProduct(bill.getProductId());
		
		
		// Rule 0 - The percentage based discounts do not apply on groceries.
		if(! product.getCategory().toUpperCase().contains(Constants.DISCOUNT_PRODUCT_CATEGORY))
		{
			// Rule 1 - If the user is an employee of the store, he gets a 30% discount
			if(user.getId().toUpperCase().contains(Constants.USER_EMPLOYEE)) {
				discountPercentage = Constants.EMPLOYEE_DISCOUNT;
				isDoscountApplied = true;
				
			}
			
			// Rule 2 - If the user is an affiliate of the store, he gets a 10% discount
			else if(user.getId().toUpperCase().contains(Constants.USER_AFFLIATE)) {
				discountPercentage = Constants.AFFLIATE_DISCOUNT;
				isDoscountApplied = true;
				
			}
				
			// Rule 3 - If the user has been a customer for over 2 years, he gets a 5% discount.
			else if(user.getId().toUpperCase().contains(Constants.USER_GENERAL) 
					&& Utils.numberOfYears(user.getJoiningDate(), bill.getDateOfPurchase()) > 2) {
				discountPercentage = Constants.EMPLOYEE_DISCOUNT;
				isDoscountApplied = true;
				
			}
		
		}
			// Rule 4 - For every $100 on the bill, there would be a $ 5 discount 
			// (e.g. for $ 990, you get $ 45 as a discount).
		if (isDoscountApplied)
			discountAmount =  bill.getAmount() * discountPercentage / 100.00 ;			
		else {	
				double multiply = (double)bill.getAmount()/100 ;
				discountAmount = 5 * multiply;
			}	
		// Rule 6 - A user can get only one of the percentage based discounts on a bill.
		
		return new Discount(bill.getCustomerid(), bill.getCustomerName(), 
							bill.getId(), product.getName(), product.getCategory(),
										discountAmount, discountPercentage, new Date());
	}
		
	
}
