package com.example.rest.webservices.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.rest.webservices.utils.Utils;

@Service
public class UserDaoService {
	
	///////////////////////////////////////////////////
	// Demo List of Users
	///////////////////////////////////////////////////	
	private static List<User> users = new ArrayList<User>();
	private static Utils utils = new Utils();
		
	static {
		users.add(new User("emp001","Employee One", utils.parseDate("2019-01-15")));	
		users.add(new User("emp002","Employee two", utils.parseDate("2014-02-14")));
		users.add(new User("affl001","Affliate One",utils.parseDate("2010-01-15")));
		users.add(new User("affl002","Affliate Two",utils.parseDate("2018-12-15")));
		users.add(new User("cust001","customer one",utils.parseDate("2017-01-15")));	
		users.add(new User("cust001","customer two",utils.parseDate("2016-01-15")));
		}
	
	
	
	///////////////////////////////////////////////////
	// Find a user
	///////////////////////////////////////////////////	
	public User findUser(String id) {
		for(User user:users) {
			if(user.getId().equalsIgnoreCase(id)) {
				return user;
			}
		}
		return null;
	}
	///////////////////////////////////////////////////
	// Save a user - for testing
	///////////////////////////////////////////////////	
	public User save(User user) {
		 if(null != user.getId())
			 users.add(user);
		 return user;
	}
	///////////////////////////////////////////////////
	// Find all users - For Test
	///////////////////////////////////////////////////	
	public List<User> getAllUsers() {
		return users;
	}
}
