package com.example.rest.webservices.utils;

public interface Constants {

	public static final String USER_EMPLOYEE = "EMP";
	public static final String USER_AFFLIATE = "AFF";
	public static final String USER_GENERAL = "CUST";
	public static final String DISCOUNT_PRODUCT_CATEGORY = "GROCERY";
	
	
	public static final int EMPLOYEE_DISCOUNT = 20;
	public static final int AFFLIATE_DISCOUNT = 10;
	public static final int GENERAL_CUSTOMER_OVER_2_YEARS_DISCOUNT = 5;
	
	
}
