package com.example.rest.webservices.discounts;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.rest.webservices.bill.Bill;
import com.example.rest.webservices.bill.BillGet;

@RestController
public class CalculateDiscountResurceController {

	@Autowired
	private CalclulateDiscountService service;
	

	
	@GetMapping(path="/test")
	public String forTest() {
		return "Discount Rest API Test";
	}
	
	 @PostMapping(path="/test/1")
	  public String forTest(@RequestBody Bill bill) {
		 
		 if(null==bill.getCustomerid() || bill.getCustomerid().length() < 4)
			 throw new InvalidCustomerIdException("Cust id -" + bill.getCustomerid());
	  
	  	  return service.getHello(bill); 
	  }
	 ///////////////////////////////////////////////////////////////////////////////////////////////////
	 // SAMPLE - : discounts?id=1&customerName=Bibhu&customerid=affl001&productId=2&amount=300.00
	 //														&&dateOfPurchase=2019-05-18T07:44:14.503+0000
	 /////////////////////////////////////////////////////////////////////////////////////////////////////
	 @GetMapping(path="/discounts")
	 public Discount calculateDisounts(@Valid BillGet bill) {
		 if(null==bill.getCustomerid() || bill.getCustomerid().length() < 4)
			 throw new InvalidCustomerIdException("Cust id -" + bill.getCustomerid());
		  return service.getDiscount(bill); 
	 }
	 
	  @PostMapping(path="/discounts/post")
	  public Discount calculateDiscountsPost (@Valid @RequestBody Bill bill) {
		  if(null==bill.getCustomerid() || bill.getCustomerid().length() < 4)
				 throw new InvalidCustomerIdException("Cust id -" + bill.getCustomerid());
	  	  return service.getDiscount(bill); 
	  }
	 
	
}
