package com.example.rest.webservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@ComponentScan("com.example.rest.webservices")
@SpringBootApplication
public class CalculateDiscountsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculateDiscountsApplication.class, args);
	}

}
