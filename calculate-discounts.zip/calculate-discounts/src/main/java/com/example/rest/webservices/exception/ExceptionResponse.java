package com.example.rest.webservices.exception;

import java.util.Date;

public class ExceptionResponse {

		//Time stamp
		private Date timestamp;
		
		//message
		private String message;
		
		//exception details
		private String details;

		///////////////////////////////////////////////////
		// Constructor
		///////////////////////////////////////////////////		
		public ExceptionResponse(Date timestamp, String message, String details) {
			super();
			this.timestamp = timestamp;
			this.message = message;
			this.details = details;
		}
		
		///////////////////////////////////////////////////
		// Get time stamp
		///////////////////////////////////////////////////		
		public Date getTimestamp() {
			return timestamp;
		}
		
		///////////////////////////////////////////////////
		// Get exception Message
		///////////////////////////////////////////////////		
		public String getMessage() {
			return message;
		}

		///////////////////////////////////////////////////
		// Get Specific details
		///////////////////////////////////////////////////		
		public String getDetails() {
			return details;
		}
		
		@Override
		public String toString() {
			return "ExceptionResponse [timestamp=" + timestamp + ", message=" + message + ", details=" + details + "]";
		}
}
