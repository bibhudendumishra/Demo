package com.example.rest.webservices.product;

public class Product {
	

	private Integer id;
	private String name;
	private String category;
	
	///////////////////////////////////////////////////
	// Demo Constructor
	///////////////////////////////////////////////////	
	public Product(Integer id, String name, String category) {
		super();
		this.id = id;
		this.name = name;
		this.category = category;
	}
	
	///////////////////////////////////////////////////
	// Default Constructor
	///////////////////////////////////////////////////	

	protected Product() {}
	
	
	///////////////////////////////////////////////////
	// Getters & setters for Id
	///////////////////////////////////////////////////	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	///////////////////////////////////////////////////
	// Getters & setters for Name
	///////////////////////////////////////////////////	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	///////////////////////////////////////////////////
	// Getters & setters for category
	///////////////////////////////////////////////////	
	public String getCategory() {
		return category;
	}
	@Override
	public String toString() {
		return "ProductType [id=" + id + ", name=" + name + ", category=" + category + "]";
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	

}
