package com.example.rest.webservices.bill;


public class BillGet {

	private String id;
	private String customerName;
	private String customerid;
	private String productId;
	private String amount;
	private String dateOfPurchase;
	
	
	protected BillGet () {}
	
	public BillGet(String id, String customerName, String customerid, String productId, String amount,
			String dateOfPurchase) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.customerid = customerid;
		this.productId = productId;
		this.amount = amount;
		this.dateOfPurchase = dateOfPurchase;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}

	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getDateOfPurchase() {
		return dateOfPurchase;
	}
	public void setDateOfPurchase(String dateOfPurchase) {
		this.dateOfPurchase = dateOfPurchase;
	}



	@Override
	public String toString() {
		return "BillGet [id=" + id + ", customerName=" + customerName + ", customerid=" + customerid + ", productId="
				+ productId + ", amount=" + amount + ", dateOfPurchase=" + dateOfPurchase + "]";
	}
}
