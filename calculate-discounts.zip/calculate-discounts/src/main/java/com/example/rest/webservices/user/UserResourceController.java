package com.example.rest.webservices.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriComponents;

@RestController
public class UserResourceController {

	@Autowired
	private UserDaoService service;
	
	//GET /users - retrieveAllUsers	
	@GetMapping(path="/users")
	public List<User> RetrieveAllUsers(){
	
		return service.getAllUsers();
	}
	

	@GetMapping(path="/users/{id}")
	public User RetrieveUsers(@PathVariable String id){
	
		User user = service.findUser(id);
		
		
		return user;
	}
	
	// POST - Create a User
	// input - details of User
	// Output - Created and return the URI
	
	@PostMapping("/users")
	public ResponseEntity<Object> CreateUser(@RequestBody User user) {
		User savedUser = service.save(user);
		
		UriComponents location = ServletUriComponentsBuilder
				.fromCurrentRequest()
				.path("/{id}")
				.buildAndExpand(savedUser.getId());
		
		//Return the location of the resource being created. Helps debugging
		return ResponseEntity.created(location.toUri()).build();
		
	}
}
