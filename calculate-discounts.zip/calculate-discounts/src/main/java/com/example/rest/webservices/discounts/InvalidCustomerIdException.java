package com.example.rest.webservices.discounts;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.LENGTH_REQUIRED)
public class InvalidCustomerIdException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidCustomerIdException(String arg0) {
		super(arg0);
	}
}
