	package com.example.rest.webservices.discounts;

import java.util.Date;

public class Discount {
	
	private String customerId;
	private String customerName;
	private Integer billId;
	private String productName;
	private String productCategory;
	private Double discountAmount;
	private Integer dicountPercentage;
	private Date dateOfBill;
		

	public Discount(String customerId, String customerName, Integer billId, 
					String productName, String productCategory,	Double discountAmount, 
					Integer dicountPercentage, Date dateOfCheck) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.billId = billId;
		this.productName = productName;
		this.productCategory = productCategory;
		this.discountAmount = discountAmount;
		this.dicountPercentage = dicountPercentage;
		this.dateOfBill = dateOfCheck;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Integer getBillId() {
		return billId;
	}
	public void setBillId(Integer billId) {
		this.billId = billId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public Double getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(Double discountAmount) {
		this.discountAmount = discountAmount;
	}
	public Integer getDicountPercentage() {
		return dicountPercentage;
	}
	public void setDicountPercentage(Integer dicountPercentage) {
		this.dicountPercentage = dicountPercentage;
	}
	public Date getDateOfCheck() {
		return dateOfBill;
	}
	public void setDateOfCheck(Date dateOfCheck) {
		this.dateOfBill = dateOfCheck;
	}
	
	
	@Override
	public String toString() {
		return "Discount [customerId=" + customerId + ", customerName=" + customerName + ", billId=" + billId
				+ ", productName=" + productName + ", productCategory=" + productCategory + ", discountAmount="
				+ discountAmount + ", dicountPercentage=" + dicountPercentage + ", dateOfCheck=" + dateOfBill + "]";
	}
}
