package com.example.rest.webservices.user;

import java.util.Date;

public class User {

	private String id;
	private String name;
	private Date joiningDate;

	
	///////////////////////////////////////////////////
	// Constructor 
	///////////////////////////////////////////////////	
	public User(String Id, String Name, Date joiningDate) {
		super();
		this.id = Id;
		this.name = Name;
		this.joiningDate = joiningDate;
	
	}
	
	protected User() {}
	
	///////////////////////////////////////////////////
	// Getters & setters for Id
	///////////////////////////////////////////////////	
	public String getId() {
		return id;
	}
	public void setId(String Id) {
		this.id = Id;
	}
	///////////////////////////////////////////////////
	// Getters & setters for Name 
	///////////////////////////////////////////////////	
	public String getName() {
		return name;
	}
	public void setName(String Name) {
		this.name = Name;
	}
	///////////////////////////////////////////////////
	// Getters & setters for joiningDate
	///////////////////////////////////////////////////	
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	///////////////////////////////////////////////////
	// To String
	///////////////////////////////////////////////////	
	
	@Override
	public String toString() {
		return " [Id=" + id + ", Name=" + name + ", joiningDate=" + joiningDate + "]";
	}
	
}
