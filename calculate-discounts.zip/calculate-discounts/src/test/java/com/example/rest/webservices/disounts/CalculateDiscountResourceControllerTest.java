package com.example.rest.webservices.disounts;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.example.rest.webservices.discounts.CalculateDiscountResurceController;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@WebMvcTest(CalculateDiscountResurceController.class)
public class CalculateDiscountResourceControllerTest {
	@Autowired
	private MockMvc mockMvc;
	
	/////////////////////////////////////////////////////////////////////////////
	// Get /discount SUCCESS Test scenario
	///////////////////////////////////////////////////////////////////////////
	@Test
	public void discountsTestGet_Success_Test() throws Exception {
		//Call GET "/discounts" application/json
		
		RequestBuilder request = MockMvcRequestBuilders
											.get("/discounts?id=1&customerName=Bibhu&customerid=affl001&productId=2&amount=300.00&dateOfPurchase=2011-05-14T12:38:56.593+0000")
											.accept(MediaType.APPLICATION_JSON);
		@SuppressWarnings("unused")
		MvcResult result = mockMvc
							.perform(request)
							.andExpect(status().isOk())
							.andExpect(content().json("{\"customerId\": \"affl001\",\"customerName\": \"Bibhu\",\"billId\": 1,\"productName\": \"Product Two\", \"productCategory\": \"retail\", \"discountAmount\": 30, \"dicountPercentage\": 10}"))
							.andReturn();
	}
	
	/////////////////////////////////////////////////////////////////////////////
	// Get /discount FAILURE Test scenario
	///////////////////////////////////////////////////////////////////////////
	@Test
	public void discountsTestGet_Failure_Test() throws Exception {
		//Call GET "/discounts" application/json
		
		RequestBuilder request = MockMvcRequestBuilders
											.get("/discounts?id=1&customerName=Bibhu&customerid=&productId=2&amount=300.00&dateOfPurchase=2011-05-14T12:38:56.593+0000")
											.accept(MediaType.APPLICATION_JSON);
		@SuppressWarnings("unused")
		MvcResult result = mockMvc
							.perform(request)
							.andExpect(status().isInternalServerError())
							.andExpect(content().json("{\"message\": \"Cust id -\"}"))
							.andReturn();
	}
	
	/////////////////////////////////////////////////////////////////////////////
	// GET /discount via POST SUCCESS scenario
	///////////////////////////////////////////////////////////////////////////
	@Test
	public void discountsTestPost_Success_Test() throws Exception {
		//Call POST "/discounts/post" application/json
		
		RequestBuilder request = MockMvcRequestBuilders
											.post("/discounts/post")
											.accept(MediaType.APPLICATION_JSON)
											.content("{\"id\": \"1\",\"customerName\":\"Bibhu\",\"customerid\" : \"affl001\",\"productId\" : 2,\"amount\" : 300.00,\"dateOfPurchase\": \"2011-05-14T12:38:56.593+0000\"}")
											.contentType(MediaType.APPLICATION_JSON);
		
		@SuppressWarnings("unused")
		MvcResult result = mockMvc
							.perform(request)
							.andExpect(status().isOk())
							.andExpect(content().json("{\"customerId\": \"affl001\",\"customerName\": \"Bibhu\",\"billId\": 1,\"productName\": \"Product Two\", \"productCategory\": \"retail\", \"discountAmount\": 30, \"dicountPercentage\": 10}"))
							.andReturn();
	}
	
	/////////////////////////////////////////////////////////////////////////////
	// GET /discount via POST FAILURE scenario
	///////////////////////////////////////////////////////////////////////////
	@Test
	public void discountsTestPost_Failure_Test() throws Exception {
		//Call POST "/discounts/post" application/json
		
		RequestBuilder request = MockMvcRequestBuilders
											.post("/discounts/post")
											.accept(MediaType.APPLICATION_JSON)
											.content("{\"id\": \"1\",\"customerName\":\"Bibhu\",\"customerid\" : \"\",\"productId\" : 2,\"amount\" : 300.00,\"dateOfPurchase\": \"2011-05-14T12:38:56.593+0000\"}")
											.contentType(MediaType.APPLICATION_JSON);
		
		@SuppressWarnings("unused")
		MvcResult result = mockMvc
							.perform(request)
							.andExpect(status().isInternalServerError())
							.andExpect(content().json("{\"message\": \"Cust id -\"}"))
							.andReturn();
	}
	
	
	@Test
	public void hello_test() throws Exception {
		//Call GET "/test" application/json
		RequestBuilder request = MockMvcRequestBuilders
											.get("/test")
											.accept(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc
							.perform(request)
							.andExpect(status().isOk())
							.andReturn();
		
		assertEquals("Discount Rest API Test", result.getResponse().getContentAsString());
	}
	
	@Test
	public void hello_test_1() throws Exception {
		//Call POST "/test/1" application/json
		
		RequestBuilder request = MockMvcRequestBuilders
											.post("/test/1")
											.accept(MediaType.APPLICATION_JSON)
											.content("{\"id\": \"1\",\"customerName\":\"Bibhu\",\"customerid\" : \"affl001\",\"productId\" : 2,\"amount\" : 300.00,\"dateOfPurchase\": \"2011-05-14T12:38:56.593+0000\"}")
											.contentType(MediaType.APPLICATION_JSON);
		
		@SuppressWarnings("unused")
		MvcResult result = mockMvc
							.perform(request)
							.andExpect(status().isOk())
							//.andExpect(content().string("hello"))
							.andReturn();
		
		//assertEquals("Discount Rest API Test", result.getResponse().getContentAsString());
	}
	
}
