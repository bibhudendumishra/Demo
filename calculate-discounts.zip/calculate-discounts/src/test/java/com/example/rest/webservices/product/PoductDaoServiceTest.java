package com.example.rest.webservices.product;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Date;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;


public class PoductDaoServiceTest {

		@Autowired
		private ProductTypeDaoService productService;
		
		/////////////////////////////////////////////////////////////////////////////
		// Find User Success Scenario
		///////////////////////////////////////////////////////////////////////////
		@Test
		public void findUser_Success_Test() {
			productService = new ProductTypeDaoService();
			int id =1;
			Product actualProduct = productService.findProduct(id);
			Product ExpectedProduct = new Product(1,"Product One","grocery");
			
			assertEquals(actualProduct.getId(), ExpectedProduct.getId());
			assertEquals(actualProduct.getName(), ExpectedProduct.getName());
		}
		
		/////////////////////////////////////////////////////////////////////////////
		// Find User Success Scenario
		///////////////////////////////////////////////////////////////////////////
		@Test
		public void findUser_Failure_Test() {
			productService = new ProductTypeDaoService();
			Product actualProduct = productService.findProduct(44);
					
			assertNull(actualProduct);
			
		}
}
