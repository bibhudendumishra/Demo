package com.example.rest.webservices.user;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Date;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class UserDaoServiceTest {

	@Autowired
	private UserDaoService userService;
	
	/////////////////////////////////////////////////////////////////////////////
	// Find User Success Scenario
	///////////////////////////////////////////////////////////////////////////
	@Test
	public void findUser_Success_Test() {
		userService = new UserDaoService();
		User actualUser = userService.findUser("emp001");
		User ExpectedUser = new User("emp001","Employee One",new Date());
		
		assertEquals(actualUser.getId(), ExpectedUser.getId());
		assertEquals(actualUser.getName(), ExpectedUser.getName());
	}
	
	/////////////////////////////////////////////////////////////////////////////
	// Find User Success Scenario
	///////////////////////////////////////////////////////////////////////////
	@Test
	public void findUser_Failure_Test() {
		userService = new UserDaoService();
		User actualUser = userService.findUser("emp004");
				
		assertNull(actualUser);
		
	}
	
}
