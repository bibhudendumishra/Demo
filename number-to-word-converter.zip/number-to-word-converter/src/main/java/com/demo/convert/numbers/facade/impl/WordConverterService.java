package com.demo.convert.numbers.facade.impl;

import com.demo.convert.numbers.dao.NumberDao;
import com.demo.convert.numbers.dao.impl.NumberDaoImpl;
import com.demo.convert.numbers.exception.NumberExceptionMessage;
import com.demo.convert.numbers.facade.WordConverter;
import com.demo.convert.numbers.model.Number;
import com.demo.convert.numbers.model.Word;

public class WordConverterService implements  WordConverter{

	public String convertToWord(String number) {
	
		try {
				NumberDao numberConverter = new NumberDaoImpl(new Number(number));
	        
				Word word = numberConverter.convertNumberToWord();
	        
				return word.getWord();
				
			} catch(NumberExceptionMessage ex) {
				System.out.println(" Exception Caught " + ex.getMessage());
			}
		
		return null;
	}

}
