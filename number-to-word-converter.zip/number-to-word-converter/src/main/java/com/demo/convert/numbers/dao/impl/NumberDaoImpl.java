package com.demo.convert.numbers.dao.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.demo.convert.numbers.dao.NumberDao;
import com.demo.convert.numbers.exception.NumberExceptionMessage;
import com.demo.convert.numbers.model.NumberWordMapper;
import com.demo.convert.numbers.model.Word;
import com.demo.convert.numbers.model.Number;

public class NumberDaoImpl implements NumberDao {
	
	private Number number;
	private static NumberWordMapper mapper = new NumberWordMapper();
	
	public NumberDaoImpl(Number number) throws NumberExceptionMessage {
		super();
		
		Pattern pattern = Pattern.compile("\\s");
		Matcher matcher = pattern.matcher(number.getNumber().trim());
		
		if(number.getNumber()==null)
			throw new NumberExceptionMessage("Null input");
		
		else if(number.getNumber().trim().isEmpty())
			throw new NumberExceptionMessage("Invalid Inpt - Empty or white space only");
		
		else if(! number.getNumber().matches("[0-9]+") )
			throw new NumberExceptionMessage("Invalid Input - Only Numeric expected");
		
		else if(matcher.find())
			throw new NumberExceptionMessage("Invalid Input - Only Numeric expected");
		
		this.number = number;
	}

	public Number getNumber() {
		return number;
	}

	public void setNumber(Number number) {
		this.number = number;
	}
	

	public Word convertNumberToWord() throws NumberExceptionMessage {
			try {	
				int numberN = Integer.parseInt(number.getNumber().trim());
				return new Word(convertToWord(numberN).toUpperCase());
			} catch(Exception ex) {
				throw new NumberExceptionMessage(ex.getMessage());
			}
			
	}
	public Word convertNumberToWord(Number numberN) throws NumberExceptionMessage {
		try {	
				int number = Integer.parseInt(numberN.getNumber().trim());
				return new Word(convertToWord(number).toUpperCase());
			} catch(Exception ex) {
				throw new NumberExceptionMessage(ex.getMessage());
			}
	}

	public void printResults(String printString) {
		// TODO Auto-generated method stub
		
	}
	
	private String convertToWord(int number) {
		
		if(number<0)
			return ("-" + convertToWord(number));
		
		if(number<20)
			return mapper.getWordMapping(number).toString();
		
		if(number<100)
			return (number % 10 == 0) ? mapper.getWordMapping(number).toString() : " " +
										mapper.getWordMapping(number - (number%10)) + " " + 
										mapper.getWordMapping(number%10);
		
		if(number<1000)
			return mapper.getWordMapping(number/100).toString() + " Hundred" +  
									 ((number % 100==0) ? "" : " and"+convertToWord(number%100));
		
		if(number<1000000)
			return convertToWord(number/1000) + " Thousand" +  
									 ((number % 1000==0) ? "" : " "+convertToWord(number%1000));
		
		
		if(number<1000000000)
			return convertToWord(number/1000000) + " Million" +  
									((number % 1000000==0) ? "" : " " + convertToWord(number%1000000));
		
		return null;
		
	}

	
}
