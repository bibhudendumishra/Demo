package com.demo.convert.numbers.facade;

public interface WordConverter {
	
	String convertToWord(String str);

}
