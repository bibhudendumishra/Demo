package com.demo.convert.numbers.dao;

import com.demo.convert.numbers.model.Word;
import com.demo.convert.numbers.exception.NumberExceptionMessage;
import com.demo.convert.numbers.model.Number;

public interface NumberDao {
 
	Word convertNumberToWord(Number numberN) throws NumberExceptionMessage;
	Word convertNumberToWord() throws NumberExceptionMessage;
	void printResults(String printString);
}
