package com.demo.convert.numbers.dao;

public interface NumberDao {
	
	String getNumberToWordMapping(int num);
}
